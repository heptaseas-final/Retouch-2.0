//
//  Color+App.swift
//  Retouch
//
//  Created by Davin P on 25/10/26.
//

import SwiftUI

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255)
    }
    static let appMagenta = Color(hex: 0x963C60)
    static let appInactive = Color(hex: 0x454546)
    static let spotlightColor = Color(hex: 0x1D1D1D)
    static let appLightCapsule = Color(hex: 0x54656F)
    static let appLightFace = Color(hex: 0xFAFAFA)
    static let lightNeutral = Color(hex: 0xFFFFFF)
    static let lightWarm = Color(hex: 0xFFECBB)
    static let lightCool = Color(hex: LightingTuning.softBlue)
    static let pickerGlow = Color(hex: 0xD94D66)
    static let lightGlow = Color(hex: 0xC29973)
}
